using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterController : MonoBehaviour
{
    bool isGrounded;
    // Start is called before the first frame update
    void Start()
    {
      if()
    }

    private void FixedUpdate()
    {
        //Grounded = isGrounded();
    }

  public void Groundedm()
  {
        if (isGrounded = false)
        {

        }

  }

    void HandleMovement()
    {

    }



}








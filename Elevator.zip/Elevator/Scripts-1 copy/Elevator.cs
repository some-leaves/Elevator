using UnityEngine;
//TODO: Make sure your project has Dotween installed from the asset store
using DG.Tweening;

public class Elevator : MonoBehaviour
{
    public void GoToFloor(int floor)
    {
        //TODO: Write a single line of code that moves the transform along the Y axis using transform.DOMoveY
        //      and the value should be something that is a function of the floor number


        transform.DOMoveY(floor,2f,false);
    }
}
